export const environment = {
  production: true,
  apiUrl:"http://meanapp-env.9b8hn5ktj2.us-east-2.elasticbeanstalk.com/api/"
};
